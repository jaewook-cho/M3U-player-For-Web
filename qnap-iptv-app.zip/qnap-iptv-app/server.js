const express = require('express');
const path = require('path');

const app = express();

const PORT = process.env.PORT || 8091; // DLNA Cast(8090)와 겹치지 않도록 기본 8091 사용
const M3U_URL = process.env.M3U_URL || 'http://192.168.0.20/playlist.m3u';
const DLNA_URL = process.env.DLNA_URL || 'http://192.168.0.20:8090';

// 정적 파일 서빙
app.use(express.static(path.join(__dirname, 'public')));

// hls.js 라이브러리 (타이젠/구형 브라우저용 HLS 폴리필) 서빙
app.get('/vendor/hls.min.js', (req, res) => {
  res.sendFile(path.join(__dirname, 'node_modules', 'hls.js', 'dist', 'hls.min.js'));
});

// 프론트에서 DLNA Cast 링크 등 설정값을 가져가기 위한 엔드포인트
app.get('/api/config', (req, res) => {
  res.json({ dlnaUrl: DLNA_URL });
});

// m3u는 서버(백엔드)에서 가져와 그대로 전달 -> 브라우저 CORS 문제 회피
app.get('/api/playlist', async (req, res) => {
  try {
    const response = await fetch(M3U_URL, { cache: 'no-store' });
    if (!response.ok) {
      throw new Error('HTTP ' + response.status);
    }
    const text = await response.text();
    res.type('text/plain; charset=utf-8').send(text);
  } catch (err) {
    console.error('Failed to fetch playlist:', err.message);
    res.status(502).json({ error: 'M3U 재생목록을 불러오지 못했습니다: ' + err.message });
  }
});

app.listen(PORT, () => {
  console.log('IPTV app listening on port ' + PORT);
  console.log('M3U source: ' + M3U_URL);
  console.log('DLNA Cast link: ' + DLNA_URL);
});
