# QNAP IPTV Live (m3u 플레이어)

DLNA Home Cast 앱과 동일한 톤의 IPTV(m3u) 웹앱입니다.
- 재생목록: `http://192.168.0.20/playlist.m3u`
- 서비스 포트: **8091** (DLNA Cast 앱 8090과 충돌 없음)
- DLNA Cast 앱으로 이동 링크 내장 (`http://192.168.0.20:8090`)

## 주요 기능
- 📺 M3U 자동 읽기 (서버가 대신 가져와 CORS 문제 없음)
- 📂 group-title별 카테고리 탭
- 🔎 채널 검색
- ⭐ 즐겨찾기 (브라우저 저장)
- ▶️ 채널 클릭 즉시 재생
- ⏭️ 페이지 새로고침 없이 `<video>` 소스만 교체 → 빠른 채널 전환
- 🔄 M3U 새로고침 버튼
- 🖥️ PC 브라우저 / 📱 모바일·태블릿 지원 (반응형)
- 📺 전체화면, 🔊 볼륨/음소거
- 삼성 타이젠(Family Hub 냉장고 등) 브라우저 호환:
  - 프레임워크 없는 순수 HTML/CSS/JS
  - hls.js를 로컬 번들로 제공 (`.m3u8` 스트림 재생, 네이티브 HLS 미지원 브라우저 대응)
  - webkitRequestFullscreen 등 구형 webkit API 폴백 처리

## QNAP Container Station에 설치하는 방법

### ⚠️ 왜 "YAML 붙여넣기(Create Application)"만으로는 실패하는가
Container Station의 **Create Application → YAML 붙여넣기** 방식은 `docker-compose.yml` **텍스트만** NAS 내부 경로
(`/share/CACHEDEV2_DATA/.qpkg/container-station/data/application/이름/`)에 저장합니다.
이 프로젝트처럼 `Dockerfile`, `server.js`, `public/` 폴더가 같이 있어야 빌드되는 앱은
그 경로에 이 파일들이 없기 때문에 `build: .`가 실패하고, 이어서 존재하지 않는 도커허브 이미지를
당겨오려다 `pull access denied`까지 겹쳐서 에러가 납니다.

**따라서 반드시 아래처럼 "먼저 이미지를 빌드 → 그 다음 실행"의 2단계로 진행해야 합니다.**

### 방법 A (권장): SSH로 이미지 빌드 후, Container Station GUI로 실행
1. File Station 등으로 이 프로젝트 폴더 전체(zip 압축 풀어서)를
   NAS 공유폴더에 업로드합니다. 예: `/share/Container/qnap-iptv-app`
   - 이때 `Dockerfile`, `server.js`, `package.json`, `public/` 폴더가 전부 같은 위치에 있어야 합니다.
2. QNAP에서 **SSH 접속**을 켠 뒤 (제어판 → 텔넷/SSH) 터미널로 접속합니다.
3. 아래 명령으로 이미지를 먼저 빌드합니다 (이 단계는 Dockerfile이 실제로 존재하는 폴더에서 실행해야 합니다):
   ```bash
   cd /share/Container/qnap-iptv-app
   docker build -t qnap-iptv-app:latest .
   ```
4. 빌드가 끝나면(`docker images`로 `qnap-iptv-app`이 보이는지 확인) Container Station GUI로 이동합니다.
5. **애플리케이션(Applications) → 만들기(Create) → YAML 만들기**에서
   이번엔 `docker-compose.yml` 대신 **`docker-compose.gui-run-only.yml`** 내용을 붙여넣습니다.
   (이 파일은 `build: .`가 없고 `image: qnap-iptv-app:latest`만 있어서, 방금 만든 로컬 이미지를 그대로 실행합니다.)
6. 애플리케이션 이름을 `iptv`로 하고 생성하면 정상적으로 뜹니다.

### 방법 B: SSH만으로 전부 처리 (가장 간단·확실함)
GUI를 아예 거치지 않고 터미널에서 빌드부터 실행까지 한 번에 끝냅니다.
```bash
# NAS에 SSH 접속 후, Dockerfile이 있는 프로젝트 폴더에서
cd /share/Container/qnap-iptv-app
docker compose up -d --build
```
정상 기동 후 `http://192.168.0.20:8091` 로 접속하면 채널 목록이 표시됩니다.
이후 컨테이너는 Container Station GUI의 "실행 중인 컨테이너" 목록에도 그대로 보이고,
거기서 시작/중지/재시작을 GUI로 관리할 수 있습니다.

### 방법 C: Container Station GUI에서 이미지 빌드 기능 사용
일부 Container Station 버전은 **이미지(Images) → 빌드(Build)** 메뉴에서
NAS 상의 폴더 경로를 지정해 Dockerfile 기반 빌드를 지원합니다.
그 경우 `/share/Container/qnap-iptv-app`를 빌드 컨텍스트로 지정하면
GUI만으로도 이미지 빌드가 가능하며, 빌드 완료 후 방법 A의 5~6번과 동일하게 실행하면 됩니다.

## 환경변수
| 변수 | 기본값 | 설명 |
|---|---|---|
| `PORT` | `8091` | 앱이 사용할 포트 (DLNA Cast 8090과 겹치지 않게) |
| `M3U_URL` | `http://192.168.0.20/playlist.m3u` | m3u 재생목록 위치 |
| `DLNA_URL` | `http://192.168.0.20:8090` | 상단 "DLNA Cast로 이동" 버튼이 이동할 주소 |

## 삼성 냉장고(Tizen) 브라우저에서 보기
Family Hub 브라우저에서 `http://192.168.0.20:8091` 주소를 입력하면 됩니다.
- 채널 목록/검색/즐겨찾기는 터치로 조작 가능하도록 버튼 크기를 넉넉하게 설계했습니다.
- 스트림이 `.m3u8`(HLS)라면 내장된 hls.js가 자동으로 재생을 처리합니다.
- 스트림이 `.ts`/직접 재생 가능한 형식이면 `<video>` 태그가 바로 재생합니다.
- Tizen 브라우저 버전에 따라 자동재생이 차단될 수 있어, 채널 클릭 시 명시적으로 `play()`를 호출하도록 구현했습니다(사용자 동작 이후 호출이라 대부분 정상 동작).

## 커스터마이징
- 디자인 색상/레이아웃: `public/style.css`
- 동작 로직(즉시 채널 전환, 즐겨찾기 등): `public/app.js`
- 서버(프록시, 포트, 환경변수): `server.js`
