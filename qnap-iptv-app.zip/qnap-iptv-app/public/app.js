(function () {
  'use strict';

  var state = {
    channels: [],
    groups: [],
    activeGroup: '__all__',
    searchTerm: '',
    favorites: loadFavorites(),
    currentChannel: null,
    hls: null,
    isPlaying: false
  };

  var els = {
    channelList: document.getElementById('channelList'),
    groupTabs: document.getElementById('groupTabs'),
    tabAll: document.querySelector('.tab[data-group="__all__"]'),
    tabFav: document.querySelector('.tab[data-group="__fav__"]'),
    searchInput: document.getElementById('searchInput'),
    refreshBtn: document.getElementById('refreshBtn'),
    player: document.getElementById('player'),
    playerPlaceholder: document.getElementById('playerPlaceholder'),
    npName: document.getElementById('npName'),
    npDot: document.getElementById('npDot'),
    prevBtn: document.getElementById('prevBtn'),
    nextBtn: document.getElementById('nextBtn'),
    playPauseBtn: document.getElementById('playPauseBtn'),
    stopBtn: document.getElementById('stopBtn'),
    favBtn: document.getElementById('favBtn'),
    muteBtn: document.getElementById('muteBtn'),
    volumeSlider: document.getElementById('volumeSlider'),
    fullscreenBtn: document.getElementById('fullscreenBtn'),
    fsHeaderBtn: document.getElementById('fsHeaderBtn'),
    dlnaLink: document.getElementById('dlnaLink'),
    listTitle: document.getElementById('listTitle'),
    listCount: document.getElementById('listCount'),
    playerSection: document.getElementById('playerSection')
  };

  // ---------- Favorites (localStorage) ----------
  function loadFavorites() {
    try {
      var raw = window.localStorage.getItem('iptv_favorites');
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function saveFavorites() {
    try {
      window.localStorage.setItem('iptv_favorites', JSON.stringify(state.favorites));
    } catch (e) { /* ignore */ }
  }

  function isFavorite(channel) {
    return state.favorites.indexOf(channel.url) !== -1;
  }

  function toggleFavorite(channel) {
    var idx = state.favorites.indexOf(channel.url);
    if (idx === -1) {
      state.favorites.push(channel.url);
    } else {
      state.favorites.splice(idx, 1);
    }
    saveFavorites();
    renderList();
    updateFavButton();
  }

  // ---------- M3U parsing ----------
  function parseM3U(text) {
    var lines = text.split(/\r?\n/);
    var channels = [];
    var pending = null;

    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].trim();
      if (!line) continue;

      if (line.indexOf('#EXTINF') === 0) {
        var groupMatch = line.match(/group-title="([^"]*)"/i);
        var logoMatch = line.match(/tvg-logo="([^"]*)"/i);
        var nameMatch = line.match(/,(.*)$/);
        pending = {
          group: (groupMatch && groupMatch[1]) ? groupMatch[1] : '기타',
          logo: logoMatch ? logoMatch[1] : '',
          name: (nameMatch && nameMatch[1]) ? nameMatch[1].trim() : '이름없음'
        };
      } else if (line.indexOf('#') !== 0) {
        if (pending) {
          pending.url = line;
          pending.id = channels.length;
          channels.push(pending);
          pending = null;
        }
      }
    }
    return channels;
  }

  function extractGroups(channels) {
    var seen = {};
    var groups = [];
    channels.forEach(function (ch) {
      if (!seen[ch.group]) {
        seen[ch.group] = true;
        groups.push(ch.group);
      }
    });
    groups.sort(function (a, b) { return a.localeCompare(b, 'ko'); });
    return groups;
  }

  // ---------- Loading playlist ----------
  function loadPlaylist() {
    els.channelList.innerHTML = '<div class="empty-state">채널 목록을 불러오는 중...</div>';
    fetch('/api/playlist', { cache: 'no-store' })
      .then(function (res) {
        if (!res.ok) { throw new Error('서버 응답 오류 (' + res.status + ')'); }
        return res.text();
      })
      .then(function (text) {
        state.channels = parseM3U(text);
        state.groups = extractGroups(state.channels);
        renderGroupTabs();
        renderList();
      })
      .catch(function (err) {
        els.channelList.innerHTML =
          '<div class="empty-state">⚠️ 재생목록을 불러오지 못했습니다.<br>' + escapeHtml(err.message) + '</div>';
      });
  }

  function loadDlnaLink() {
    fetch('/api/config')
      .then(function (res) { return res.json(); })
      .then(function (cfg) {
        if (cfg && cfg.dlnaUrl) { els.dlnaLink.href = cfg.dlnaUrl; }
      })
      .catch(function () { /* keep default href */ });
  }

  // ---------- Rendering ----------
  function renderGroupTabs() {
    els.groupTabs.innerHTML = '';
    state.groups.forEach(function (group) {
      var btn = document.createElement('button');
      btn.className = 'tab';
      btn.dataset.group = group;
      btn.textContent = group;
      btn.addEventListener('click', function () { setActiveGroup(group); });
      els.groupTabs.appendChild(btn);
    });
  }

  function setActiveGroup(group) {
    state.activeGroup = group;
    var all = document.querySelectorAll('.tab');
    for (var i = 0; i < all.length; i++) {
      all[i].classList.toggle('active', all[i].dataset.group === group);
    }
    renderList();
  }

  function getVisibleChannels() {
    var list = state.channels;

    if (state.activeGroup === '__fav__') {
      list = list.filter(function (ch) { return isFavorite(ch); });
    } else if (state.activeGroup !== '__all__') {
      list = list.filter(function (ch) { return ch.group === state.activeGroup; });
    }

    if (state.searchTerm) {
      var term = state.searchTerm.toLowerCase();
      list = list.filter(function (ch) { return ch.name.toLowerCase().indexOf(term) !== -1; });
    }

    return list;
  }

  function renderList() {
    var visible = getVisibleChannels();

    els.listTitle.textContent =
      state.activeGroup === '__all__' ? '전체 채널' :
      state.activeGroup === '__fav__' ? '즐겨찾기' : state.activeGroup;
    els.listCount.textContent = visible.length + '개 채널';

    els.channelList.innerHTML = '';

    if (visible.length === 0) {
      els.channelList.innerHTML = '<div class="empty-state">표시할 채널이 없습니다.</div>';
      return;
    }

    visible.forEach(function (ch) {
      var row = document.createElement('div');
      row.className = 'channel-row';
      if (state.currentChannel && state.currentChannel.url === ch.url) {
        row.classList.add('active');
      }

      var iconHtml = ch.logo
        ? '<img src="' + escapeHtml(ch.logo) + '" alt="" onerror="this.parentNode.textContent=\'📺\'">'
        : '📺';

      row.innerHTML =
        '<div class="ch-icon">' + iconHtml + '</div>' +
        '<div class="ch-meta">' +
          '<div class="ch-name">' + escapeHtml(ch.name) + '</div>' +
          '<div class="ch-group">' + escapeHtml(ch.group) + '</div>' +
        '</div>' +
        '<button class="ch-fav' + (isFavorite(ch) ? ' active' : '') + '" title="즐겨찾기">' +
          (isFavorite(ch) ? '★' : '☆') +
        '</button>' +
        '<button class="ch-play-btn">재생</button>';

      var favBtn = row.querySelector('.ch-fav');
      favBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleFavorite(ch);
      });

      row.addEventListener('click', function () { playChannel(ch); });

      els.channelList.appendChild(row);
    });
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ---------- Player: instant channel switching ----------
  // 핵심 요구사항: 채널 변경 시 페이지를 새로 열지 않고
  // 현재 <video> 엘리먼트의 스트림 소스만 교체한다.
  function playChannel(channel) {
    state.currentChannel = channel;
    els.npName.textContent = channel.name;
    els.npDot.classList.add('live');
    els.playerPlaceholder.style.display = 'none';

    loadSource(channel.url);
    updateFavButton();
    updatePlayPauseIcon(true);
    renderActiveRowOnly();
  }

  function loadSource(url) {
    // 기존 HLS 인스턴스 정리
    if (state.hls) {
      state.hls.destroy();
      state.hls = null;
    }

    var isHls = /\.m3u8($|\?)/i.test(url);

    if (isHls && window.Hls && window.Hls.isSupported()) {
      // 대부분의 데스크톱/모바일 브라우저 및 구형 타이젠 브라우저 대응
      state.hls = new window.Hls({ lowLatencyMode: true });
      state.hls.loadSource(url);
      state.hls.attachMedia(els.player);
      state.hls.on(window.Hls.Events.MANIFEST_PARSED, function () {
        els.player.play().catch(function () {});
      });
      state.hls.on(window.Hls.Events.ERROR, function (event, data) {
        if (data && data.fatal) {
          console.warn('HLS fatal error, retry with native playback', data);
          els.player.src = url;
          els.player.play().catch(function () {});
        }
      });
    } else {
      // 네이티브 HLS 지원 브라우저(Safari, 최신 Tizen 등) 또는 일반 스트림(mp4/ts 등)
      els.player.src = url;
      els.player.load();
      els.player.play().catch(function (e) { console.warn('autoplay blocked', e); });
    }
  }

  function renderActiveRowOnly() {
    // 전체 재렌더 대신 active 클래스만 갱신 (빠른 전환)
    var rows = els.channelList.querySelectorAll('.channel-row');
    var visible = getVisibleChannels();
    rows.forEach(function (row, idx) {
      var ch = visible[idx];
      if (!ch) return;
      row.classList.toggle('active', state.currentChannel && ch.url === state.currentChannel.url);
    });
  }

  function updateFavButton() {
    if (!state.currentChannel) {
      els.favBtn.classList.remove('active');
      els.favBtn.textContent = '☆';
      return;
    }
    var fav = isFavorite(state.currentChannel);
    els.favBtn.classList.toggle('active', fav);
    els.favBtn.textContent = fav ? '★' : '☆';
  }

  function updatePlayPauseIcon(playing) {
    state.isPlaying = playing;
    els.playPauseBtn.textContent = playing ? '❚❚' : '▶';
  }

  function stepChannel(direction) {
    var visible = getVisibleChannels();
    if (visible.length === 0) return;

    var currentIndex = -1;
    if (state.currentChannel) {
      for (var i = 0; i < visible.length; i++) {
        if (visible[i].url === state.currentChannel.url) { currentIndex = i; break; }
      }
    }

    var nextIndex;
    if (currentIndex === -1) {
      nextIndex = 0;
    } else {
      nextIndex = (currentIndex + direction + visible.length) % visible.length;
    }

    playChannel(visible[nextIndex]);
  }

  // ---------- Event bindings ----------
  els.tabAll.addEventListener('click', function () { setActiveGroup('__all__'); });
  els.tabFav.addEventListener('click', function () { setActiveGroup('__fav__'); });

  els.searchInput.addEventListener('input', function (e) {
    state.searchTerm = e.target.value;
    renderList();
  });

  els.refreshBtn.addEventListener('click', function () {
    loadPlaylist();
  });

  els.prevBtn.addEventListener('click', function () { stepChannel(-1); });
  els.nextBtn.addEventListener('click', function () { stepChannel(1); });

  els.playPauseBtn.addEventListener('click', function () {
    if (!state.currentChannel) return;
    if (els.player.paused) {
      els.player.play().catch(function () {});
      updatePlayPauseIcon(true);
    } else {
      els.player.pause();
      updatePlayPauseIcon(false);
    }
  });

  els.stopBtn.addEventListener('click', function () {
    els.player.pause();
    els.player.removeAttribute('src');
    els.player.load();
    if (state.hls) { state.hls.destroy(); state.hls = null; }
    els.npDot.classList.remove('live');
    els.npName.textContent = '정지됨';
    updatePlayPauseIcon(false);
  });

  els.favBtn.addEventListener('click', function () {
    if (!state.currentChannel) return;
    toggleFavorite(state.currentChannel);
  });

  els.muteBtn.addEventListener('click', function () {
    els.player.muted = !els.player.muted;
    els.muteBtn.textContent = els.player.muted ? '🔇' : '🔊';
  });

  els.volumeSlider.addEventListener('input', function (e) {
    var v = Number(e.target.value) / 100;
    els.player.volume = v;
    if (v === 0) {
      els.player.muted = true;
      els.muteBtn.textContent = '🔇';
    } else if (els.player.muted) {
      els.player.muted = false;
      els.muteBtn.textContent = '🔊';
    }
  });

  function requestFs(el) {
    if (el.requestFullscreen) return el.requestFullscreen();
    if (el.webkitRequestFullscreen) return el.webkitRequestFullscreen(); // Tizen/webkit
    if (el.msRequestFullscreen) return el.msRequestFullscreen();
  }

  els.fullscreenBtn.addEventListener('click', function () { requestFs(els.playerSection); });
  els.fsHeaderBtn.addEventListener('click', function () { requestFs(els.playerSection); });

  els.player.addEventListener('play', function () { updatePlayPauseIcon(true); });
  els.player.addEventListener('pause', function () { updatePlayPauseIcon(false); });

  // ---------- Init ----------
  els.player.volume = Number(els.volumeSlider.value) / 100;
  loadDlnaLink();
  loadPlaylist();
})();
